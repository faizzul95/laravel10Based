<?php

namespace App\Services\Generals\Constants;

final class LoginType {
    
    public const NORMAL = 1;
    public const TOKEN = 2;
    public const SOCIALITE = 3;
    
}